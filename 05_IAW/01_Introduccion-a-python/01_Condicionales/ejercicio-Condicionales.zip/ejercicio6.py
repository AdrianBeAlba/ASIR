#Pasamos un numero 
numero=int(input("Dame un numero entero: "))
#Si el reso de la division (%) del numero entre dos es igual a 0 significa que el numero introucido es par.
if (numero % 2 == 0):
    print("Es par")
else:
    print("No es par")