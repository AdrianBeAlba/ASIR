numero1 = int(input("introduce un numero: ")) 
numero2 = int(input("introduce otro numero: ")) 
numero3 = int(input("introduce otro numero: ")) 

# Encontrar el mayor de los tres números
#El metodo max() muestra el numero mayor entre los argumentos presentados, en este caso los 3 numeros
print(max(numero2,numero1,numero3))