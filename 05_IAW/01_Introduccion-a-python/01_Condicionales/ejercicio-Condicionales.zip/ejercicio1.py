#Solcicitar numero
#Equivalente a read, muestra texto por pantalla y permite escribir, lo escrito se guarda en la variable como int (numero) si es posible.
numero = int(input("introduce un numero: ")) 

#Comprobacion, dentro de los () se encuentra la condicion, si la variable numero es igual(==) a 1000 pasa a la siguiente linea
if (numero==1000):
        #Todo lo tabulado a partir del : cuenta como resultado de que la condicional sea true
        print("Bien echo!")