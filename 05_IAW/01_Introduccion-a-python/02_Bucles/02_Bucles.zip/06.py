# EJERCICIO 6: 
# Escribir un programa que muestre por pantalla la tabla de multiplicar del 1 al 10. 

x=1
while x<=10:
    print(x*10)
    x+=1