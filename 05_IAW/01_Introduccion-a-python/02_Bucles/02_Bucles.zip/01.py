#Pide palabra
palabra=input("Dame una palabra: ")
#Establecemos variable del bucle
x=1
#Mientras la variable sea menor o igual a 10 ejecuta el codigo
while x<=10:
    #Imprime palabra
    print(palabra)
    #Aumenta en 1 la variale del bucle
    x+=1