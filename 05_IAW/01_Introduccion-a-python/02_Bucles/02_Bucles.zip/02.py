#Pide edad
edad=int(input("Dime tu edad: "))
#Establecemos variable de bucle
x=1
#Mientras la variable sea menor de la edad muestra la variable
while x<=edad:
    print(x)
    x+=1